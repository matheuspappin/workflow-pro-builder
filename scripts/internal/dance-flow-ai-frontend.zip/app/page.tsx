"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Sparkles,
  Users,
  DollarSign,
  Calendar,
  MessageSquare,
  BarChart3,
  Shield,
  Zap,
  ChevronRight,
  Menu,
  X,
  Check,
  Star,
  ArrowRight,
  Play,
} from "lucide-react"

const features = [
  {
    icon: BarChart3,
    title: "Visao Geral Inteligente",
    description: "Cards com metricas em tempo real de faturamento, alunos ativos e muito mais.",
  },
  {
    icon: DollarSign,
    title: "Gestao Financeira",
    description: "Controle exato de quanto pagar para cada professor baseado no valor fixo por aula.",
  },
  {
    icon: Users,
    title: "Monitoramento de Evasao",
    description: "Alertas gerados por IA para identificar alunos que nao comparecem as aulas.",
  },
  {
    icon: MessageSquare,
    title: "Chat IA Integrado",
    description: "Assistente inteligente com recomendacoes personalizadas para seu estudio.",
  },
  {
    icon: Calendar,
    title: "Agenda Inteligente",
    description: "Gerenciamento completo de horarios, turmas e disponibilidade de salas.",
  },
  {
    icon: Zap,
    title: "Automacao WhatsApp",
    description: "Comunicacao automatizada com alunos e professores via WhatsApp.",
  },
]

const stats = [
  { value: "500+", label: "Estudios Ativos" },
  { value: "50k+", label: "Alunos Gerenciados" },
  { value: "95%", label: "Satisfacao" },
  { value: "2M+", label: "Aulas Registradas" },
]

const plans = [
  {
    name: "Starter",
    price: "97",
    description: "Perfeito para estudios iniciantes",
    features: [
      "Ate 50 alunos",
      "1 usuario admin",
      "Dashboard basico",
      "Suporte por email",
    ],
    popular: false,
  },
  {
    name: "Professional",
    price: "197",
    description: "Para estudios em crescimento",
    features: [
      "Ate 200 alunos",
      "5 usuarios admin",
      "IA integrada",
      "Chat WhatsApp",
      "Relatorios avancados",
      "Suporte prioritario",
    ],
    popular: true,
  },
  {
    name: "Enterprise",
    price: "397",
    description: "Para grandes redes de estudios",
    features: [
      "Alunos ilimitados",
      "Usuarios ilimitados",
      "Multi-unidades",
      "API personalizada",
      "Treinamento dedicado",
      "Suporte 24/7",
    ],
    popular: false,
  },
]

const testimonials = [
  {
    name: "Maria Silva",
    role: "Proprietaria - Studio Dance Art",
    content: "O DanceFlow AI transformou completamente a gestao do meu estudio. A IA realmente ajuda a prever evasao!",
    rating: 5,
  },
  {
    name: "Carlos Mendes",
    role: "Diretor - Academia Ritmo",
    content: "A integracao com WhatsApp e incrivel. Reduzi 80% do tempo gasto em comunicacao manual.",
    rating: 5,
  },
  {
    name: "Ana Costa",
    role: "Gerente - Ballet Classico SP",
    content: "Os relatorios financeiros sao precisos e me ajudam a tomar decisoes mais inteligentes.",
    rating: 5,
  },
]

export default function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
        <nav className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="text-xl font-bold text-foreground">
              DanceFlow <span className="text-primary">AI</span>
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <Link href="#features" className="text-muted-foreground hover:text-foreground transition-colors">
              Recursos
            </Link>
            <Link href="#pricing" className="text-muted-foreground hover:text-foreground transition-colors">
              Precos
            </Link>
            <Link href="#testimonials" className="text-muted-foreground hover:text-foreground transition-colors">
              Depoimentos
            </Link>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <Link href="/login">
              <Button variant="ghost">Entrar</Button>
            </Link>
            <Link href="/register">
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
                Comecar Gratis
              </Button>
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-foreground" />
            ) : (
              <Menu className="w-6 h-6 text-foreground" />
            )}
          </button>
        </nav>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-background border-b border-border">
            <div className="container mx-auto px-4 py-4 flex flex-col gap-4">
              <Link href="#features" className="text-muted-foreground hover:text-foreground transition-colors">
                Recursos
              </Link>
              <Link href="#pricing" className="text-muted-foreground hover:text-foreground transition-colors">
                Precos
              </Link>
              <Link href="#testimonials" className="text-muted-foreground hover:text-foreground transition-colors">
                Depoimentos
              </Link>
              <div className="flex flex-col gap-2 pt-4 border-t border-border">
                <Link href="/login">
                  <Button variant="ghost" className="w-full">Entrar</Button>
                </Link>
                <Link href="/register">
                  <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                    Comecar Gratis
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4">
        <div className="container mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium mb-8">
            <Sparkles className="w-4 h-4" />
            Powered by AI
          </div>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-foreground max-w-4xl mx-auto leading-tight text-balance">
            Gestao inteligente para{" "}
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              estudios de danca
            </span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mt-6 text-pretty">
            Sistema completo que une administracao, comunicacao via WhatsApp e inteligencia artificial 
            para transformar a gestao do seu estudio.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-10">
            <Link href="/register">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2 w-full sm:w-auto">
                Comecar Gratis
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="gap-2 bg-transparent">
              <Play className="w-4 h-4" />
              Ver Demo
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20 max-w-3xl mx-auto">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl md:text-4xl font-bold text-primary">{stat.value}</div>
                <div className="text-sm text-muted-foreground mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 bg-secondary/30">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Tudo que voce precisa em um so lugar
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Funcionalidades pensadas especificamente para a realidade dos estudios de danca brasileiros.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="bg-card border-border hover:border-primary/50 transition-colors group">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-card-foreground mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Como funciona
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Em apenas 3 passos simples, transforme a gestao do seu estudio.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              { step: "1", title: "Cadastre seu estudio", description: "Crie sua conta em minutos e configure as informacoes basicas do seu estudio." },
              { step: "2", title: "Importe seus dados", description: "Adicione alunos, professores e turmas. Podemos importar de planilhas existentes." },
              { step: "3", title: "Deixe a IA trabalhar", description: "Nossa IA analisa seus dados e fornece insights valiosos automaticamente." },
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-primary-foreground">{item.step}</span>
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-4 bg-secondary/30">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Planos que cabem no seu bolso
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Escolha o plano ideal para o tamanho do seu estudio. Todos incluem 14 dias de teste gratis.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, index) => (
              <Card
                key={index}
                className={`relative bg-card border-border ${
                  plan.popular ? "border-2 border-primary shadow-lg scale-105" : ""
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-medium">
                    Mais Popular
                  </div>
                )}
                <CardContent className="p-6">
                  <h3 className="text-xl font-semibold text-card-foreground">{plan.name}</h3>
                  <p className="text-muted-foreground text-sm mt-1">{plan.description}</p>
                  <div className="mt-6">
                    <span className="text-4xl font-bold text-card-foreground">R${plan.price}</span>
                    <span className="text-muted-foreground">/mes</span>
                  </div>
                  <ul className="mt-6 space-y-3">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Check className="w-4 h-4 text-primary" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Link href="/register">
                    <Button
                      className={`w-full mt-6 ${
                        plan.popular
                          ? "bg-primary hover:bg-primary/90 text-primary-foreground"
                          : "bg-secondary hover:bg-secondary/80 text-secondary-foreground"
                      }`}
                    >
                      Comecar Agora
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              O que nossos clientes dizem
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Veja como o DanceFlow AI esta transformando estudios por todo o Brasil.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="flex gap-1 mb-4">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                    ))}
                  </div>
                  <p className="text-muted-foreground text-sm mb-4">{`"${testimonial.content}"`}</p>
                  <div>
                    <div className="font-semibold text-card-foreground">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-primary to-accent">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
            Pronto para transformar seu estudio?
          </h2>
          <p className="text-primary-foreground/80 max-w-2xl mx-auto mb-8">
            Junte-se a centenas de estudios que ja estao usando o DanceFlow AI para crescer.
          </p>
          <Link href="/register">
            <Button size="lg" variant="secondary" className="gap-2">
              Comecar Teste Gratis
              <ChevronRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-sidebar text-sidebar-foreground">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <Link href="/" className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-primary-foreground" />
                </div>
                <span className="text-xl font-bold">
                  DanceFlow <span className="text-primary">AI</span>
                </span>
              </Link>
              <p className="text-sidebar-foreground/70 text-sm">
                Sistema completo de gestao para estudios de danca com inteligencia artificial.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Produto</h4>
              <ul className="space-y-2 text-sm text-sidebar-foreground/70">
                <li><Link href="#features" className="hover:text-sidebar-foreground transition-colors">Recursos</Link></li>
                <li><Link href="#pricing" className="hover:text-sidebar-foreground transition-colors">Precos</Link></li>
                <li><Link href="#" className="hover:text-sidebar-foreground transition-colors">Integrações</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Empresa</h4>
              <ul className="space-y-2 text-sm text-sidebar-foreground/70">
                <li><Link href="#" className="hover:text-sidebar-foreground transition-colors">Sobre</Link></li>
                <li><Link href="#" className="hover:text-sidebar-foreground transition-colors">Blog</Link></li>
                <li><Link href="#" className="hover:text-sidebar-foreground transition-colors">Carreiras</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-sm text-sidebar-foreground/70">
                <li><Link href="#" className="hover:text-sidebar-foreground transition-colors">Central de Ajuda</Link></li>
                <li><Link href="#" className="hover:text-sidebar-foreground transition-colors">Contato</Link></li>
                <li><Link href="#" className="hover:text-sidebar-foreground transition-colors">Status</Link></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-sidebar-border pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-sidebar-foreground/70">
              2026 DanceFlow AI. Todos os direitos reservados.
            </p>
            <div className="flex gap-6 text-sm text-sidebar-foreground/70">
              <Link href="#" className="hover:text-sidebar-foreground transition-colors">Privacidade</Link>
              <Link href="#" className="hover:text-sidebar-foreground transition-colors">Termos</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
