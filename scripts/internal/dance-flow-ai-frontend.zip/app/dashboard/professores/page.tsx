"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Search,
  Plus,
  MoreVertical,
  Phone,
  Mail,
  GraduationCap,
  DollarSign,
  Calendar,
  Star,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useSearchParams } from "next/navigation"
import { Suspense } from "react"
import Loading from "./loading"

interface Teacher {
  id: number
  name: string
  email: string
  phone: string
  specialties: string[]
  perClassRate: number
  status: "ativo" | "inativo"
  classesThisMonth: number
  rating: number
  hireDate: string
}

const initialTeachers: Teacher[] = [
  {
    id: 1,
    name: "Ana Paula Rodrigues",
    email: "ana.paula@email.com",
    phone: "(11) 98888-1111",
    specialties: ["Ballet", "Contemporaneo"],
    perClassRate: 80,
    status: "ativo",
    classesThisMonth: 24,
    rating: 4.9,
    hireDate: "2022-03-15",
  },
  {
    id: 2,
    name: "Carlos Eduardo Silva",
    email: "carlos.e@email.com",
    phone: "(11) 98888-2222",
    specialties: ["Hip Hop", "Jazz"],
    perClassRate: 70,
    status: "ativo",
    classesThisMonth: 20,
    rating: 4.7,
    hireDate: "2023-01-10",
  },
  {
    id: 3,
    name: "Lucas Oliveira",
    email: "lucas.o@email.com",
    phone: "(11) 98888-3333",
    specialties: ["Hip Hop"],
    perClassRate: 65,
    status: "ativo",
    classesThisMonth: 18,
    rating: 4.8,
    hireDate: "2023-06-20",
  },
  {
    id: 4,
    name: "Marina Santos",
    email: "marina.s@email.com",
    phone: "(11) 98888-4444",
    specialties: ["Salsa", "Jazz"],
    perClassRate: 75,
    status: "ativo",
    classesThisMonth: 16,
    rating: 4.6,
    hireDate: "2022-08-05",
  },
  {
    id: 5,
    name: "Roberto Ferreira",
    email: "roberto.f@email.com",
    phone: "(11) 98888-5555",
    specialties: ["Contemporaneo"],
    perClassRate: 85,
    status: "inativo",
    classesThisMonth: 0,
    rating: 4.5,
    hireDate: "2021-11-30",
  },
]

const allSpecialties = ["Ballet", "Jazz", "Hip Hop", "Contemporaneo", "Salsa"]

export default function TeachersPage() {
  const { toast } = useToast()
  const searchParams = useSearchParams()
  const [teachers, setTeachers] = useState<Teacher[]>(initialTeachers)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newTeacher, setNewTeacher] = useState({
    name: "",
    email: "",
    phone: "",
    specialty: "",
    perClassRate: "",
  })

  const filteredTeachers = teachers.filter((teacher) => {
    const matchesSearch = teacher.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || teacher.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const handleAddTeacher = () => {
    if (!newTeacher.name || !newTeacher.email || !newTeacher.phone || !newTeacher.specialty) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatorios.",
        variant: "destructive",
      })
      return
    }

    const teacher: Teacher = {
      id: teachers.length + 1,
      name: newTeacher.name,
      email: newTeacher.email,
      phone: newTeacher.phone,
      specialties: [newTeacher.specialty],
      perClassRate: Number(newTeacher.perClassRate) || 70,
      status: "ativo",
      classesThisMonth: 0,
      rating: 5.0,
      hireDate: new Date().toISOString().split("T")[0],
    }

    setTeachers([...teachers, teacher])
    setNewTeacher({ name: "", email: "", phone: "", specialty: "", perClassRate: "" })
    setIsDialogOpen(false)
    toast({
      title: "Professor adicionado!",
      description: `${teacher.name} foi cadastrado com sucesso.`,
    })
  }

  const totalActiveTeachers = teachers.filter(t => t.status === "ativo").length
  const totalClassesThisMonth = teachers.reduce((acc, t) => acc + t.classesThisMonth, 0)
  const totalPayment = teachers.reduce((acc, t) => acc + (t.classesThisMonth * t.perClassRate), 0)

  return (
    <div className="min-h-screen bg-background">
      <Header title="Professores" />

      <div className="p-6">
        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <GraduationCap className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Professores Ativos</p>
                  <p className="text-2xl font-bold text-card-foreground">{totalActiveTeachers}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Aulas este Mes</p>
                  <p className="text-2xl font-bold text-card-foreground">{totalClassesThisMonth}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-success/10 flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-success" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total a Pagar</p>
                  <p className="text-2xl font-bold text-card-foreground">R$ {totalPayment.toLocaleString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-warning/10 flex items-center justify-center">
                  <Star className="w-5 h-5 text-warning" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Avaliacao Media</p>
                  <p className="text-2xl font-bold text-card-foreground">
                    {(teachers.filter(t => t.status === "ativo").reduce((acc, t) => acc + t.rating, 0) / totalActiveTeachers).toFixed(1)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Actions */}
        <Card className="bg-card border-border mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <div className="flex flex-col sm:flex-row gap-4 flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por nome ou email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 bg-background"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[150px] bg-background">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="ativo">Ativos</SelectItem>
                    <SelectItem value="inativo">Inativos</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2">
                    <Plus className="w-4 h-4" />
                    Novo Professor
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Adicionar Novo Professor</DialogTitle>
                    <DialogDescription>
                      Preencha os dados do novo professor.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nome Completo *</Label>
                      <Input
                        id="name"
                        value={newTeacher.name}
                        onChange={(e) => setNewTeacher({ ...newTeacher, name: e.target.value })}
                        placeholder="Nome do professor"
                        className="bg-background"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email *</Label>
                      <Input
                        id="email"
                        type="email"
                        value={newTeacher.email}
                        onChange={(e) => setNewTeacher({ ...newTeacher, email: e.target.value })}
                        placeholder="email@exemplo.com"
                        className="bg-background"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Telefone *</Label>
                      <Input
                        id="phone"
                        value={newTeacher.phone}
                        onChange={(e) => setNewTeacher({ ...newTeacher, phone: e.target.value })}
                        placeholder="(11) 99999-9999"
                        className="bg-background"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="specialty">Especialidade Principal *</Label>
                      <Select
                        value={newTeacher.specialty}
                        onValueChange={(value) => setNewTeacher({ ...newTeacher, specialty: value })}
                      >
                        <SelectTrigger className="bg-background">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          {allSpecialties.map((spec) => (
                            <SelectItem key={spec} value={spec}>{spec}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="perClassRate">Valor por Aula (R$)</Label>
                      <Input
                        id="perClassRate"
                        type="number"
                        value={newTeacher.perClassRate}
                        onChange={(e) => setNewTeacher({ ...newTeacher, perClassRate: e.target.value })}
                        placeholder="70"
                        className="bg-background"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                      Cancelar
                    </Button>
                    <Button onClick={handleAddTeacher} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                      Adicionar Professor
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardContent>
        </Card>

        {/* Teachers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTeachers.map((teacher) => (
            <Card key={teacher.id} className="bg-card border-border">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white font-bold text-lg">
                      {teacher.name.split(" ").map(n => n[0]).slice(0, 2).join("")}
                    </div>
                    <div>
                      <CardTitle className="text-lg text-card-foreground">{teacher.name}</CardTitle>
                      <div className="flex items-center gap-1 mt-1">
                        <Star className="w-4 h-4 fill-warning text-warning" />
                        <span className="text-sm text-muted-foreground">{teacher.rating}</span>
                      </div>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>Editar</DropdownMenuItem>
                      <DropdownMenuItem>Ver Agenda</DropdownMenuItem>
                      <DropdownMenuItem>Historico de Pagamentos</DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive">Desativar</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {teacher.specialties.map((spec) => (
                    <Badge key={spec} variant="secondary" className="bg-primary/10 text-primary">
                      {spec}
                    </Badge>
                  ))}
                  <Badge variant={teacher.status === "ativo" ? "default" : "secondary"} className={teacher.status === "ativo" ? "bg-success/20 text-success-foreground" : ""}>
                    {teacher.status === "ativo" ? "Ativo" : "Inativo"}
                  </Badge>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mail className="w-4 h-4" />
                    {teacher.email}
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="w-4 h-4" />
                    {teacher.phone}
                  </div>
                </div>

                <div className="pt-3 border-t border-border">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold text-primary">{teacher.classesThisMonth}</p>
                      <p className="text-xs text-muted-foreground">Aulas este mes</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-success">R$ {(teacher.classesThisMonth * teacher.perClassRate).toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">A receber</p>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-border">
                  <p className="text-xs text-muted-foreground">
                    Valor por aula: <span className="font-medium text-foreground">R$ {teacher.perClassRate}</span>
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredTeachers.length === 0 && (
          <Card className="bg-card border-border">
            <CardContent className="py-12 text-center">
              <GraduationCap className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhum professor encontrado.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

export function Loading() {
  return null
}
