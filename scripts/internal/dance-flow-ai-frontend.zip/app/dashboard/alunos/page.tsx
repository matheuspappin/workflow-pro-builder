"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Search,
  Plus,
  MoreVertical,
  Phone,
  Mail,
  AlertTriangle,
  CheckCircle,
  Filter,
  Download,
  Users,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { useSearchParams } from "next/navigation"
import LoadingComponent from "./loading"

interface Student {
  id: number
  name: string
  email: string
  phone: string
  modality: string
  status: "ativo" | "inativo" | "risco"
  enrollmentDate: string
  lastClass: string
  monthlyFee: number
  paymentStatus: "pago" | "pendente" | "atrasado"
}

const initialStudents: Student[] = [
  {
    id: 1,
    name: "Maria Silva",
    email: "maria@email.com",
    phone: "(11) 99999-1111",
    modality: "Ballet",
    status: "ativo",
    enrollmentDate: "2024-01-15",
    lastClass: "2026-01-20",
    monthlyFee: 250,
    paymentStatus: "pago",
  },
  {
    id: 2,
    name: "Joao Santos",
    email: "joao@email.com",
    phone: "(11) 99999-2222",
    modality: "Hip Hop",
    status: "risco",
    enrollmentDate: "2024-03-10",
    lastClass: "2026-01-05",
    monthlyFee: 200,
    paymentStatus: "atrasado",
  },
  {
    id: 3,
    name: "Ana Costa",
    email: "ana@email.com",
    phone: "(11) 99999-3333",
    modality: "Jazz",
    status: "ativo",
    enrollmentDate: "2024-02-20",
    lastClass: "2026-01-22",
    monthlyFee: 220,
    paymentStatus: "pago",
  },
  {
    id: 4,
    name: "Pedro Lima",
    email: "pedro@email.com",
    phone: "(11) 99999-4444",
    modality: "Contemporaneo",
    status: "inativo",
    enrollmentDate: "2023-11-05",
    lastClass: "2025-12-10",
    monthlyFee: 230,
    paymentStatus: "pendente",
  },
  {
    id: 5,
    name: "Carla Mendes",
    email: "carla@email.com",
    phone: "(11) 99999-5555",
    modality: "Salsa",
    status: "ativo",
    enrollmentDate: "2024-06-01",
    lastClass: "2026-01-21",
    monthlyFee: 180,
    paymentStatus: "pago",
  },
  {
    id: 6,
    name: "Lucas Ferreira",
    email: "lucas@email.com",
    phone: "(11) 99999-6666",
    modality: "Hip Hop",
    status: "ativo",
    enrollmentDate: "2024-04-15",
    lastClass: "2026-01-19",
    monthlyFee: 200,
    paymentStatus: "pendente",
  },
  {
    id: 7,
    name: "Juliana Rocha",
    email: "juliana@email.com",
    phone: "(11) 99999-7777",
    modality: "Ballet",
    status: "risco",
    enrollmentDate: "2024-01-20",
    lastClass: "2026-01-08",
    monthlyFee: 250,
    paymentStatus: "atrasado",
  },
  {
    id: 8,
    name: "Bruno Alves",
    email: "bruno@email.com",
    phone: "(11) 99999-8888",
    modality: "Jazz",
    status: "ativo",
    enrollmentDate: "2024-05-10",
    lastClass: "2026-01-22",
    monthlyFee: 220,
    paymentStatus: "pago",
  },
]

const modalities = ["Ballet", "Jazz", "Hip Hop", "Contemporaneo", "Salsa"]

export default function StudentsPage() {
  const { toast } = useToast()
  const searchParams = useSearchParams()
  const [students, setStudents] = useState<Student[]>(initialStudents)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [modalityFilter, setModalityFilter] = useState<string>("all")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newStudent, setNewStudent] = useState({
    name: "",
    email: "",
    phone: "",
    modality: "",
    monthlyFee: "",
  })
  const [editStudent, setEditStudent] = useState<Student | null>(null)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)

  const filteredStudents = students.filter((student) => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || student.status === statusFilter
    const matchesModality = modalityFilter === "all" || student.modality === modalityFilter
    return matchesSearch && matchesStatus && matchesModality
  })

  const handleAddStudent = () => {
    if (!newStudent.name || !newStudent.email || !newStudent.phone || !newStudent.modality) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatorios.",
        variant: "destructive",
      })
      return
    }

    const student: Student = {
      id: students.length + 1,
      name: newStudent.name,
      email: newStudent.email,
      phone: newStudent.phone,
      modality: newStudent.modality,
      status: "ativo",
      enrollmentDate: new Date().toISOString().split("T")[0],
      lastClass: "-",
      monthlyFee: Number(newStudent.monthlyFee) || 200,
      paymentStatus: "pendente",
    }

    setStudents([...students, student])
    setNewStudent({ name: "", email: "", phone: "", modality: "", monthlyFee: "" })
    setIsDialogOpen(false)
    toast({
      title: "Aluno adicionado!",
      description: `${student.name} foi matriculado com sucesso.`,
    })
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "ativo":
        return <Badge className="bg-success/20 text-success-foreground hover:bg-success/30"><CheckCircle className="w-3 h-3 mr-1" />Ativo</Badge>
      case "inativo":
        return <Badge variant="secondary">Inativo</Badge>
      case "risco":
        return <Badge className="bg-warning/20 text-warning-foreground hover:bg-warning/30"><AlertTriangle className="w-3 h-3 mr-1" />Risco</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const getPaymentBadge = (status: string) => {
    switch (status) {
      case "pago":
        return <Badge className="bg-success/20 text-success-foreground hover:bg-success/30">Pago</Badge>
      case "pendente":
        return <Badge className="bg-warning/20 text-warning-foreground hover:bg-warning/30">Pendente</Badge>
      case "atrasado":
        return <Badge variant="destructive">Atrasado</Badge>
      default:
        return <Badge variant="secondary">{status}</Badge>
    }
  }

  const stats = [
    { label: "Total de Alunos", value: students.length, icon: Users },
    { label: "Alunos Ativos", value: students.filter(s => s.status === "ativo").length, color: "text-success" },
    { label: "Em Risco", value: students.filter(s => s.status === "risco").length, color: "text-warning" },
    { label: "Inativos", value: students.filter(s => s.status === "inativo").length, color: "text-muted-foreground" },
  ]

  const handleSendEmail = (student: Student) => {
    window.open(`mailto:${student.email}?subject=DanceFlow AI - Contato&body=Ola ${student.name},`)
    toast({
      title: "Email",
      description: `Abrindo email para ${student.name}`,
    })
  }

  const handleWhatsApp = (student: Student) => {
    const phone = student.phone.replace(/\D/g, "")
    window.open(`https://wa.me/55${phone}?text=Ola ${student.name}, aqui é do DanceFlow AI!`, "_blank")
    toast({
      title: "WhatsApp",
      description: `Abrindo WhatsApp para ${student.name}`,
    })
  }

  const handleDeactivate = (student: Student) => {
    setStudents(students.map(s => 
      s.id === student.id ? { ...s, status: s.status === "inativo" ? "ativo" : "inativo" } : s
    ))
    toast({
      title: student.status === "inativo" ? "Aluno Reativado" : "Aluno Desativado",
      description: `${student.name} foi ${student.status === "inativo" ? "reativado" : "desativado"}.`,
    })
  }

  const handleExport = () => {
    const csv = [
      ["Nome", "Email", "Telefone", "Modalidade", "Status", "Mensalidade", "Pagamento"].join(","),
      ...filteredStudents.map(s => [s.name, s.email, s.phone, s.modality, s.status, s.monthlyFee, s.paymentStatus].join(","))
    ].join("\n")
    
    const blob = new Blob([csv], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "alunos-danceflow.csv"
    a.click()
    URL.revokeObjectURL(url)
    
    toast({
      title: "Exportado!",
      description: "Lista de alunos exportada com sucesso.",
    })
  }

  const handleEditStudent = () => {
    if (!editStudent) return
    setStudents(students.map(s => s.id === editStudent.id ? editStudent : s))
    setIsEditDialogOpen(false)
    setEditStudent(null)
    toast({
      title: "Aluno atualizado!",
      description: `${editStudent.name} foi atualizado com sucesso.`,
    })
  }

  return (
    <div className="min-h-screen bg-background">
      <Header title="Alunos" />

      <div className="p-6">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-card border-border">
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className={`text-2xl font-bold ${stat.color || "text-card-foreground"}`}>{stat.value}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Filters and Actions */}
        <Card className="bg-card border-border mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <div className="flex flex-col sm:flex-row gap-4 flex-1">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar por nome ou email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 bg-background"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[150px] bg-background">
                    <Filter className="w-4 h-4 mr-2" />
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos</SelectItem>
                    <SelectItem value="ativo">Ativos</SelectItem>
                    <SelectItem value="risco">Em Risco</SelectItem>
                    <SelectItem value="inativo">Inativos</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={modalityFilter} onValueChange={setModalityFilter}>
                  <SelectTrigger className="w-[180px] bg-background">
                    <SelectValue placeholder="Modalidade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas Modalidades</SelectItem>
                    {modalities.map((mod) => (
                      <SelectItem key={mod} value={mod}>{mod}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" className="gap-2 bg-transparent" onClick={handleExport}>
                  <Download className="w-4 h-4" />
                  Exportar
                </Button>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2">
                      <Plus className="w-4 h-4" />
                      Novo Aluno
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Adicionar Novo Aluno</DialogTitle>
                      <DialogDescription>
                        Preencha os dados do novo aluno para realizar a matricula.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <Label htmlFor="name">Nome Completo *</Label>
                        <Input
                          id="name"
                          value={newStudent.name}
                          onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                          placeholder="Nome do aluno"
                          className="bg-background"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email">Email *</Label>
                        <Input
                          id="email"
                          type="email"
                          value={newStudent.email}
                          onChange={(e) => setNewStudent({ ...newStudent, email: e.target.value })}
                          placeholder="email@exemplo.com"
                          className="bg-background"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Telefone *</Label>
                        <Input
                          id="phone"
                          value={newStudent.phone}
                          onChange={(e) => setNewStudent({ ...newStudent, phone: e.target.value })}
                          placeholder="(11) 99999-9999"
                          className="bg-background"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="modality">Modalidade *</Label>
                        <Select
                          value={newStudent.modality}
                          onValueChange={(value) => setNewStudent({ ...newStudent, modality: value })}
                        >
                          <SelectTrigger className="bg-background">
                            <SelectValue placeholder="Selecione a modalidade" />
                          </SelectTrigger>
                          <SelectContent>
                            {modalities.map((mod) => (
                              <SelectItem key={mod} value={mod}>{mod}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="monthlyFee">Mensalidade (R$)</Label>
                        <Input
                          id="monthlyFee"
                          type="number"
                          value={newStudent.monthlyFee}
                          onChange={(e) => setNewStudent({ ...newStudent, monthlyFee: e.target.value })}
                          placeholder="200"
                          className="bg-background"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                        Cancelar
                      </Button>
                      <Button onClick={handleAddStudent} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                        Adicionar Aluno
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Students Table */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-card-foreground">Lista de Alunos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Aluno</TableHead>
                    <TableHead>Modalidade</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Ultima Aula</TableHead>
                    <TableHead>Mensalidade</TableHead>
                    <TableHead>Pagamento</TableHead>
                    <TableHead className="text-right">Acoes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium text-foreground">{student.name}</p>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Mail className="w-3 h-3" />
                            {student.email}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{student.modality}</Badge>
                      </TableCell>
                      <TableCell>{getStatusBadge(student.status)}</TableCell>
                      <TableCell className="text-muted-foreground">{student.lastClass}</TableCell>
                      <TableCell className="text-foreground">R$ {student.monthlyFee}</TableCell>
                      <TableCell>{getPaymentBadge(student.paymentStatus)}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreVertical className="w-4 h-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleSendEmail(student)}>
                              <Mail className="w-4 h-4 mr-2" />
                              Enviar Email
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handleWhatsApp(student)}>
                              <Phone className="w-4 h-4 mr-2" />
                              WhatsApp
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => { setEditStudent(student); setIsEditDialogOpen(true); }}>Editar</DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive" onClick={() => handleDeactivate(student)}>Desativar</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            {filteredStudents.length === 0 && (
              <div className="text-center py-12">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Nenhum aluno encontrado com os filtros selecionados.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Edit Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Editar Aluno</DialogTitle>
              <DialogDescription>
                Atualize os dados do aluno.
              </DialogDescription>
            </DialogHeader>
            {editStudent && (
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Nome Completo</Label>
                  <Input
                    id="edit-name"
                    value={editStudent.name}
                    onChange={(e) => setEditStudent({ ...editStudent, name: e.target.value })}
                    className="bg-background"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-email">Email</Label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={editStudent.email}
                    onChange={(e) => setEditStudent({ ...editStudent, email: e.target.value })}
                    className="bg-background"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-phone">Telefone</Label>
                  <Input
                    id="edit-phone"
                    value={editStudent.phone}
                    onChange={(e) => setEditStudent({ ...editStudent, phone: e.target.value })}
                    className="bg-background"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-modality">Modalidade</Label>
                  <Select
                    value={editStudent.modality}
                    onValueChange={(value) => setEditStudent({ ...editStudent, modality: value })}
                  >
                    <SelectTrigger className="bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {modalities.map((mod) => (
                        <SelectItem key={mod} value={mod}>{mod}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-fee">Mensalidade (R$)</Label>
                  <Input
                    id="edit-fee"
                    type="number"
                    value={editStudent.monthlyFee}
                    onChange={(e) => setEditStudent({ ...editStudent, monthlyFee: Number(e.target.value) })}
                    className="bg-background"
                  />
                </div>
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleEditStudent} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                Salvar Alteracoes
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
