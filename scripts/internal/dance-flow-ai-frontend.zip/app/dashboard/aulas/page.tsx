"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Plus,
  Calendar,
  Clock,
  Users,
  ChevronLeft,
  ChevronRight,
  GraduationCap,
  MapPin,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface ClassItem {
  id: number
  name: string
  modality: string
  teacher: string
  day: string
  time: string
  duration: number
  room: string
  maxStudents: number
  enrolledStudents: number
  status: "ativa" | "cancelada" | "cheia"
}

const initialClasses: ClassItem[] = [
  {
    id: 1,
    name: "Ballet Infantil",
    modality: "Ballet",
    teacher: "Ana Paula Rodrigues",
    day: "Segunda",
    time: "14:00",
    duration: 60,
    room: "Sala 1",
    maxStudents: 15,
    enrolledStudents: 12,
    status: "ativa",
  },
  {
    id: 2,
    name: "Hip Hop Iniciante",
    modality: "Hip Hop",
    teacher: "Lucas Oliveira",
    day: "Segunda",
    time: "16:00",
    duration: 60,
    room: "Sala 2",
    maxStudents: 20,
    enrolledStudents: 18,
    status: "ativa",
  },
  {
    id: 3,
    name: "Jazz Adulto",
    modality: "Jazz",
    teacher: "Carlos Eduardo Silva",
    day: "Terca",
    time: "19:00",
    duration: 75,
    room: "Sala 1",
    maxStudents: 15,
    enrolledStudents: 15,
    status: "cheia",
  },
  {
    id: 4,
    name: "Ballet Adulto",
    modality: "Ballet",
    teacher: "Ana Paula Rodrigues",
    day: "Terca",
    time: "20:30",
    duration: 60,
    room: "Sala 1",
    maxStudents: 12,
    enrolledStudents: 8,
    status: "ativa",
  },
  {
    id: 5,
    name: "Salsa Casais",
    modality: "Salsa",
    teacher: "Marina Santos",
    day: "Quarta",
    time: "20:00",
    duration: 90,
    room: "Sala 2",
    maxStudents: 20,
    enrolledStudents: 16,
    status: "ativa",
  },
  {
    id: 6,
    name: "Hip Hop Teen",
    modality: "Hip Hop",
    teacher: "Lucas Oliveira",
    day: "Quarta",
    time: "17:00",
    duration: 60,
    room: "Sala 2",
    maxStudents: 18,
    enrolledStudents: 15,
    status: "ativa",
  },
  {
    id: 7,
    name: "Contemporaneo",
    modality: "Contemporaneo",
    teacher: "Ana Paula Rodrigues",
    day: "Quinta",
    time: "18:00",
    duration: 75,
    room: "Sala 1",
    maxStudents: 12,
    enrolledStudents: 10,
    status: "ativa",
  },
  {
    id: 8,
    name: "Jazz Teen",
    modality: "Jazz",
    teacher: "Carlos Eduardo Silva",
    day: "Quinta",
    time: "16:30",
    duration: 60,
    room: "Sala 2",
    maxStudents: 15,
    enrolledStudents: 12,
    status: "ativa",
  },
  {
    id: 9,
    name: "Ballet Avancado",
    modality: "Ballet",
    teacher: "Ana Paula Rodrigues",
    day: "Sexta",
    time: "19:00",
    duration: 90,
    room: "Sala 1",
    maxStudents: 10,
    enrolledStudents: 9,
    status: "ativa",
  },
  {
    id: 10,
    name: "Hip Hop Avancado",
    modality: "Hip Hop",
    teacher: "Lucas Oliveira",
    day: "Sexta",
    time: "20:00",
    duration: 75,
    room: "Sala 2",
    maxStudents: 15,
    enrolledStudents: 14,
    status: "ativa",
  },
]

const weekDays = ["Segunda", "Terca", "Quarta", "Quinta", "Sexta", "Sabado"]
const modalities = ["Ballet", "Jazz", "Hip Hop", "Contemporaneo", "Salsa"]
const teachers = ["Ana Paula Rodrigues", "Carlos Eduardo Silva", "Lucas Oliveira", "Marina Santos"]
const rooms = ["Sala 1", "Sala 2", "Sala 3"]

export default function ClassesPage() {
  const { toast } = useToast()
  const [classes, setClasses] = useState<ClassItem[]>(initialClasses)
  const [selectedDay, setSelectedDay] = useState<string>("Segunda")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [newClass, setNewClass] = useState({
    name: "",
    modality: "",
    teacher: "",
    day: "",
    time: "",
    duration: "60",
    room: "",
    maxStudents: "15",
  })

  const filteredClasses = classes.filter((c) => c.day === selectedDay)

  const handleAddClass = () => {
    if (!newClass.name || !newClass.modality || !newClass.teacher || !newClass.day || !newClass.time || !newClass.room) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatorios.",
        variant: "destructive",
      })
      return
    }

    const classItem: ClassItem = {
      id: classes.length + 1,
      name: newClass.name,
      modality: newClass.modality,
      teacher: newClass.teacher,
      day: newClass.day,
      time: newClass.time,
      duration: Number(newClass.duration),
      room: newClass.room,
      maxStudents: Number(newClass.maxStudents),
      enrolledStudents: 0,
      status: "ativa",
    }

    setClasses([...classes, classItem])
    setNewClass({
      name: "",
      modality: "",
      teacher: "",
      day: "",
      time: "",
      duration: "60",
      room: "",
      maxStudents: "15",
    })
    setIsDialogOpen(false)
    toast({
      title: "Aula criada!",
      description: `${classItem.name} foi adicionada a grade.`,
    })
  }

  const getStatusBadge = (status: string, enrolled: number, max: number) => {
    const percentage = (enrolled / max) * 100
    if (status === "cheia" || percentage >= 100) {
      return <Badge variant="destructive">Cheia</Badge>
    }
    if (status === "cancelada") {
      return <Badge variant="secondary">Cancelada</Badge>
    }
    if (percentage >= 80) {
      return <Badge className="bg-warning/20 text-warning-foreground">Quase Cheia</Badge>
    }
    return <Badge className="bg-success/20 text-success-foreground">Vagas Disponiveis</Badge>
  }

  const totalClasses = classes.length
  const totalStudentsEnrolled = classes.reduce((acc, c) => acc + c.enrolledStudents, 0)
  const avgOccupancy = Math.round(
    (classes.reduce((acc, c) => acc + (c.enrolledStudents / c.maxStudents) * 100, 0) / totalClasses)
  )

  const currentDayIndex = weekDays.indexOf(selectedDay)

  return (
    <div className="min-h-screen bg-background">
      <Header title="Aulas" />

      <div className="p-6">
        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total de Turmas</p>
                  <p className="text-2xl font-bold text-card-foreground">{totalClasses}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
                  <Users className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Alunos Matriculados</p>
                  <p className="text-2xl font-bold text-card-foreground">{totalStudentsEnrolled}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-success/10 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-success" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Ocupacao Media</p>
                  <p className="text-2xl font-bold text-card-foreground">{avgOccupancy}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-warning/10 flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-warning" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Salas em Uso</p>
                  <p className="text-2xl font-bold text-card-foreground">3</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Day Selector and Add Button */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSelectedDay(weekDays[Math.max(0, currentDayIndex - 1)])}
              disabled={currentDayIndex === 0}
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <div className="flex gap-1 overflow-x-auto pb-2 sm:pb-0">
              {weekDays.map((day) => (
                <Button
                  key={day}
                  variant={selectedDay === day ? "default" : "ghost"}
                  className={selectedDay === day ? "bg-primary text-primary-foreground" : ""}
                  onClick={() => setSelectedDay(day)}
                >
                  {day}
                </Button>
              ))}
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSelectedDay(weekDays[Math.min(weekDays.length - 1, currentDayIndex + 1)])}
              disabled={currentDayIndex === weekDays.length - 1}
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>

          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2">
                <Plus className="w-4 h-4" />
                Nova Turma
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Criar Nova Turma</DialogTitle>
                <DialogDescription>
                  Configure os detalhes da nova turma.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
                <div className="space-y-2">
                  <Label htmlFor="name">Nome da Turma *</Label>
                  <Input
                    id="name"
                    value={newClass.name}
                    onChange={(e) => setNewClass({ ...newClass, name: e.target.value })}
                    placeholder="Ex: Ballet Infantil"
                    className="bg-background"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="modality">Modalidade *</Label>
                    <Select
                      value={newClass.modality}
                      onValueChange={(value) => setNewClass({ ...newClass, modality: value })}
                    >
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {modalities.map((mod) => (
                          <SelectItem key={mod} value={mod}>{mod}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="teacher">Professor *</Label>
                    <Select
                      value={newClass.teacher}
                      onValueChange={(value) => setNewClass({ ...newClass, teacher: value })}
                    >
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {teachers.map((teacher) => (
                          <SelectItem key={teacher} value={teacher}>{teacher}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="day">Dia *</Label>
                    <Select
                      value={newClass.day}
                      onValueChange={(value) => setNewClass({ ...newClass, day: value })}
                    >
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {weekDays.map((day) => (
                          <SelectItem key={day} value={day}>{day}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="time">Horario *</Label>
                    <Input
                      id="time"
                      type="time"
                      value={newClass.time}
                      onChange={(e) => setNewClass({ ...newClass, time: e.target.value })}
                      className="bg-background"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="duration">Duracao (min)</Label>
                    <Select
                      value={newClass.duration}
                      onValueChange={(value) => setNewClass({ ...newClass, duration: value })}
                    >
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="45">45 min</SelectItem>
                        <SelectItem value="60">60 min</SelectItem>
                        <SelectItem value="75">75 min</SelectItem>
                        <SelectItem value="90">90 min</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="room">Sala *</Label>
                    <Select
                      value={newClass.room}
                      onValueChange={(value) => setNewClass({ ...newClass, room: value })}
                    >
                      <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {rooms.map((room) => (
                          <SelectItem key={room} value={room}>{room}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="maxStudents">Maximo de Alunos</Label>
                  <Input
                    id="maxStudents"
                    type="number"
                    value={newClass.maxStudents}
                    onChange={(e) => setNewClass({ ...newClass, maxStudents: e.target.value })}
                    placeholder="15"
                    className="bg-background"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={handleAddClass} className="bg-primary hover:bg-primary/90 text-primary-foreground">
                  Criar Turma
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Classes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredClasses
            .sort((a, b) => a.time.localeCompare(b.time))
            .map((classItem) => (
              <Card key={classItem.id} className="bg-card border-border hover:border-primary/50 transition-colors">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <Badge variant="outline" className="mb-2">{classItem.modality}</Badge>
                      <CardTitle className="text-lg text-card-foreground">{classItem.name}</CardTitle>
                    </div>
                    {getStatusBadge(classItem.status, classItem.enrolledStudents, classItem.maxStudents)}
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <GraduationCap className="w-4 h-4" />
                    {classItem.teacher}
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      {classItem.time} ({classItem.duration}min)
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="w-4 h-4" />
                      {classItem.room}
                    </div>
                  </div>
                  <div className="pt-3 border-t border-border">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">Ocupacao</span>
                      <span className="text-sm font-medium text-foreground">
                        {classItem.enrolledStudents}/{classItem.maxStudents} alunos
                      </span>
                    </div>
                    <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary transition-all duration-300"
                        style={{
                          width: `${(classItem.enrolledStudents / classItem.maxStudents) * 100}%`,
                        }}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
        </div>

        {filteredClasses.length === 0 && (
          <Card className="bg-card border-border">
            <CardContent className="py-12 text-center">
              <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Nenhuma aula agendada para {selectedDay}.</p>
              <Button
                className="mt-4 bg-primary hover:bg-primary/90 text-primary-foreground"
                onClick={() => setIsDialogOpen(true)}
              >
                <Plus className="w-4 h-4 mr-2" />
                Criar Nova Turma
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
