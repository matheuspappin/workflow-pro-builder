"use client"

import { useState, useRef, useEffect } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  Sparkles,
  Send,
  Loader2,
  Lightbulb,
  TrendingUp,
  Users,
  Calendar,
  AlertTriangle,
  Bot,
  User,
  RefreshCw,
} from "lucide-react"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

const suggestedQuestions = [
  {
    icon: TrendingUp,
    question: "Como posso aumentar a taxa de retencao de alunos?",
    category: "Retencao",
  },
  {
    icon: Users,
    question: "Quais alunos estao em risco de evasao?",
    category: "Evasao",
  },
  {
    icon: Calendar,
    question: "Qual o melhor horario para abrir novas turmas?",
    category: "Planejamento",
  },
  {
    icon: AlertTriangle,
    question: "Quais sao os principais problemas financeiros do estudio?",
    category: "Financeiro",
  },
]

const mockResponses: Record<string, string> = {
  "retencao": `Com base na analise dos dados do seu estudio, identifiquei algumas estrategias para aumentar a retencao:

**1. Comunicacao Proativa**
- Envie mensagens personalizadas para alunos que faltaram 2 aulas consecutivas
- Implemente lembretes automaticos de aulas via WhatsApp

**2. Programa de Fidelidade**
- Ofereça descontos progressivos para alunos com mais de 6 meses
- Crie um sistema de indicacao com beneficios

**3. Acompanhamento Individual**
- Realize avaliacoes trimestrais de evolucao
- Ofereça aulas experimentais em outras modalidades

**Previsao**: Implementando estas acoes, estimo um aumento de 15-20% na retencao nos proximos 3 meses.`,

  "evasao": `Analisei os padroes de frequencia e identifiquei **3 alunos em risco alto de evasao**:

**1. Maria Silva** (Ballet)
- Ultima aula: 3 semanas atras
- Historico: frequencia caiu de 90% para 30%
- Sugestao: Contato telefônico para entender situacao

**2. Joao Santos** (Hip Hop)
- Ultima aula: 2 semanas atras
- Historico: Pagamento atrasado + baixa frequencia
- Sugestao: Oferecer renegociacao + aula experimental

**3. Juliana Rocha** (Ballet)
- Ultima aula: 2 semanas atras
- Historico: Mudou de turno no trabalho
- Sugestao: Oferecer mudanca de horario

**Acao recomendada**: Sugiro entrar em contato com estes alunos esta semana para evitar a desistencia.`,

  "horario": `Baseado na analise de ocupacao e demanda do seu estudio:

**Melhores horarios para novas turmas:**

1. **Terça 18h00** - Sala 2 disponivel
   - Demanda: 12 interessados em Jazz Adulto
   - Taxa de ocupacao esperada: 85%

2. **Quinta 17h00** - Sala 1 disponivel
   - Demanda: 8 interessados em Contemporaneo
   - Taxa de ocupacao esperada: 70%

3. **Sabado 10h00** - Ambas salas disponiveis
   - Demanda: 15 interessados em Ballet Infantil
   - Taxa de ocupacao esperada: 90%

**Recomendacao**: Priorize a turma de Sabado 10h - maior demanda e alta probabilidade de sucesso.`,

  "financeiro": `Realizei uma analise completa das financas do estudio:

**Pontos de Atencao:**

1. **Inadimplencia** (R$ 500)
   - 2 alunos com pagamento atrasado > 10 dias
   - Impacto: 2.7% da receita mensal
   - Acao: Ativar cobranca automatica

2. **Custos com Professores** (57% das despesas)
   - Acima da media do mercado (45-50%)
   - Sugestao: Revisar carga horaria ociosa

3. **Oportunidade de Crescimento**
   - Capacidade ociosa: 25% das vagas
   - Potencial de receita adicional: R$ 4.500/mes

**Saude Financeira**: Lucro liquido de 48% - acima da media do setor (35-40%). Parabens!`,

  "default": `Entendi sua pergunta! Deixe-me analisar os dados do seu estudio para fornecer uma resposta precisa.

Com base nas informacoes disponiveis:
- Você tem **145 alunos ativos** em 5 modalidades diferentes
- O faturamento mensal atual e de **R$ 18.500**
- A taxa de retencao esta em **92%** (excelente!)

Posso ajudar com analises mais especificas sobre:
- Previsoes de faturamento
- Identificacao de tendencias
- Sugestoes de marketing
- Otimizacao de grade horaria

O que gostaria de explorar?`,
}

function getAIResponse(question: string): string {
  const lowerQuestion = question.toLowerCase()
  
  if (lowerQuestion.includes("retencao") || lowerQuestion.includes("reter") || lowerQuestion.includes("fidelizar")) {
    return mockResponses["retencao"]
  }
  if (lowerQuestion.includes("evasao") || lowerQuestion.includes("risco") || lowerQuestion.includes("desistir")) {
    return mockResponses["evasao"]
  }
  if (lowerQuestion.includes("horario") || lowerQuestion.includes("turma") || lowerQuestion.includes("abrir")) {
    return mockResponses["horario"]
  }
  if (lowerQuestion.includes("financeiro") || lowerQuestion.includes("dinheiro") || lowerQuestion.includes("receita") || lowerQuestion.includes("custo")) {
    return mockResponses["financeiro"]
  }
  
  return mockResponses["default"]
}

export default function ChatPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "Ola! Sou o assistente IA do DanceFlow. Estou aqui para ajudar a analisar os dados do seu estudio e fornecer insights valiosos. Como posso ajudar hoje?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight
    }
  }, [messages])

  const handleSend = async () => {
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    // Simulate AI response delay
    await new Promise((resolve) => setTimeout(resolve, 1500))

    const aiResponse: Message = {
      id: (Date.now() + 1).toString(),
      role: "assistant",
      content: getAIResponse(userMessage.content),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, aiResponse])
    setIsLoading(false)
  }

  const handleSuggestedQuestion = (question: string) => {
    setInput(question)
    inputRef.current?.focus()
  }

  const handleClearChat = () => {
    setMessages([
      {
        id: "1",
        role: "assistant",
        content: "Ola! Sou o assistente IA do DanceFlow. Estou aqui para ajudar a analisar os dados do seu estudio e fornecer insights valiosos. Como posso ajudar hoje?",
        timestamp: new Date(),
      },
    ])
  }

  return (
    <div className="min-h-screen bg-background">
      <Header title="Chat IA" />

      <div className="p-6 h-[calc(100vh-4rem)]">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-full">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-card-foreground flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-primary" />
                  Sugestoes
                </CardTitle>
                <CardDescription>Perguntas frequentes</CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {suggestedQuestions.map((item, index) => (
                  <button
                    key={index}
                    onClick={() => handleSuggestedQuestion(item.question)}
                    className="w-full text-left p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors group"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <item.icon className="w-4 h-4 text-primary" />
                      <span className="text-xs text-muted-foreground">{item.category}</span>
                    </div>
                    <p className="text-sm text-foreground group-hover:text-primary transition-colors">
                      {item.question}
                    </p>
                  </button>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader className="pb-3">
                <CardTitle className="text-card-foreground text-sm">Dados Analisados</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Alunos</span>
                  <span className="font-medium text-foreground">145</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Professores</span>
                  <span className="font-medium text-foreground">5</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Turmas</span>
                  <span className="font-medium text-foreground">10</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Periodo</span>
                  <span className="font-medium text-foreground">12 meses</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat Area */}
          <Card className="lg:col-span-3 bg-card border-border flex flex-col h-[calc(100vh-8rem)]">
            <CardHeader className="border-b border-border flex-shrink-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <div>
                    <CardTitle className="text-card-foreground">Assistente DanceFlow</CardTitle>
                    <CardDescription className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
                      Online - Pronto para ajudar
                    </CardDescription>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={handleClearChat}>
                  <RefreshCw className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>

            {/* Messages */}
            <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    {message.role === "assistant" && (
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
                        <Bot className="w-4 h-4 text-primary-foreground" />
                      </div>
                    )}
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                        message.role === "user"
                          ? "bg-primary text-primary-foreground rounded-br-md"
                          : "bg-secondary text-secondary-foreground rounded-bl-md"
                      }`}
                    >
                      <div className="whitespace-pre-wrap text-sm">{message.content}</div>
                      <div className={`text-xs mt-2 ${
                        message.role === "user" ? "text-primary-foreground/70" : "text-muted-foreground"
                      }`}>
                        {message.timestamp.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
                      </div>
                    </div>
                    {message.role === "user" && (
                      <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <User className="w-4 h-4 text-primary" />
                      </div>
                    )}
                  </div>
                ))}
                {isLoading && (
                  <div className="flex gap-3 justify-start">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center flex-shrink-0">
                      <Bot className="w-4 h-4 text-primary-foreground" />
                    </div>
                    <div className="bg-secondary text-secondary-foreground rounded-2xl rounded-bl-md px-4 py-3">
                      <div className="flex items-center gap-2 text-sm">
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Analisando dados...
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            {/* Input */}
            <div className="p-4 border-t border-border flex-shrink-0">
              <form
                onSubmit={(e) => {
                  e.preventDefault()
                  handleSend()
                }}
                className="flex gap-2"
              >
                <Input
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Digite sua pergunta..."
                  className="flex-1 bg-background"
                  disabled={isLoading}
                />
                <Button
                  type="submit"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                  disabled={!input.trim() || isLoading}
                >
                  {isLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                </Button>
              </form>
              <p className="text-xs text-muted-foreground mt-2 text-center">
                A IA analisa dados reais do seu estudio para fornecer recomendacoes personalizadas.
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
