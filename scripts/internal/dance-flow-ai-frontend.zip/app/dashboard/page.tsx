"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Users,
  DollarSign,
  Calendar,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  ArrowRight,
  GraduationCap,
} from "lucide-react"
import {
  Line,
  LineChart,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  Bar,
  BarChart,
  Cell,
  PieChart,
  Pie,
} from "recharts"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"
import Link from "next/link"

// Mock data
const revenueData = [
  { month: "Jan", receita: 12500, despesas: 8200 },
  { month: "Fev", receita: 14200, despesas: 8500 },
  { month: "Mar", receita: 13800, despesas: 8100 },
  { month: "Abr", receita: 15600, despesas: 8800 },
  { month: "Mai", receita: 16200, despesas: 9200 },
  { month: "Jun", receita: 18500, despesas: 9500 },
]

const classesData = [
  { name: "Ballet", alunos: 45 },
  { name: "Jazz", alunos: 32 },
  { name: "Hip Hop", alunos: 28 },
  { name: "Contemporaneo", alunos: 22 },
  { name: "Salsa", alunos: 18 },
]

const studentDistribution = [
  { name: "Criancas", value: 35, fill: "#9333ea" },
  { name: "Adolescentes", value: 28, fill: "#db2777" },
  { name: "Adultos", value: 37, fill: "#06b6d4" },
]

const evasionAlerts = [
  { id: 1, name: "Maria Silva", lastClass: "3 semanas", risk: "alto" },
  { id: 2, name: "Joao Santos", lastClass: "2 semanas", risk: "medio" },
  { id: 3, name: "Ana Costa", lastClass: "2 semanas", risk: "medio" },
]

const upcomingClasses = [
  { id: 1, name: "Ballet Infantil", time: "14:00", students: 12, teacher: "Prof. Ana" },
  { id: 2, name: "Jazz Adulto", time: "15:30", students: 8, teacher: "Prof. Carlos" },
  { id: 3, name: "Hip Hop Teen", time: "17:00", students: 15, teacher: "Prof. Lucas" },
]

const stats = [
  {
    title: "Alunos Ativos",
    value: "145",
    change: "+12%",
    trend: "up",
    icon: Users,
    color: "text-primary",
    bgColor: "bg-primary/10",
  },
  {
    title: "Faturamento Mensal",
    value: "R$ 18.500",
    change: "+8%",
    trend: "up",
    icon: DollarSign,
    color: "text-success",
    bgColor: "bg-success/10",
  },
  {
    title: "Aulas este Mes",
    value: "86",
    change: "+5%",
    trend: "up",
    icon: Calendar,
    color: "text-accent",
    bgColor: "bg-accent/10",
  },
  {
    title: "Taxa de Retencao",
    value: "92%",
    change: "-2%",
    trend: "down",
    icon: TrendingUp,
    color: "text-warning",
    bgColor: "bg-warning/10",
  },
]

export default function DashboardPage() {
  const [mounted, setMounted] = useState(false)
  const [userName, setUserName] = useState("")

  useEffect(() => {
    setMounted(true)
    const user = localStorage.getItem("danceflow_user")
    if (user) {
      const userData = JSON.parse(user)
      setUserName(userData.name || "Usuario")
    }
  }, [])

  if (!mounted) return null

  return (
    <div className="min-h-screen bg-background">
      <Header title="Dashboard" />
      
      <div className="p-6">
        {/* Welcome */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground">Ola, {userName}!</h2>
          <p className="text-muted-foreground">Aqui esta o resumo do seu estudio hoje.</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-card border-border">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className={`w-12 h-12 rounded-xl ${stat.bgColor} flex items-center justify-center`}>
                    <stat.icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div className={`flex items-center gap-1 text-sm ${
                    stat.trend === "up" ? "text-success" : "text-destructive"
                  }`}>
                    {stat.trend === "up" ? (
                      <TrendingUp className="w-4 h-4" />
                    ) : (
                      <TrendingDown className="w-4 h-4" />
                    )}
                    {stat.change}
                  </div>
                </div>
                <div className="mt-4">
                  <p className="text-2xl font-bold text-card-foreground">{stat.value}</p>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Revenue Chart */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-card-foreground">Faturamento vs Despesas</CardTitle>
              <CardDescription>Ultimos 6 meses</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  receita: { label: "Receita", color: "#9333ea" },
                  despesas: { label: "Despesas", color: "#db2777" },
                }}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis dataKey="month" className="text-muted-foreground" />
                    <YAxis className="text-muted-foreground" />
                    <ChartTooltip
                      content={({ active, payload, label }) => {
                        if (!active || !payload?.length) return null
                        return (
                          <div className="bg-background border border-border rounded-lg px-3 py-2 shadow-lg">
                            <p className="font-medium text-foreground mb-1">{label}</p>
                            {payload.map((entry, index) => (
                              <p key={index} className="text-sm" style={{ color: entry.color }}>
                                {entry.dataKey === "receita" ? "Receita" : "Despesas"}: R$ {Number(entry.value).toLocaleString()}
                              </p>
                            ))}
                          </div>
                        )
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="receita"
                      stroke="#9333ea"
                      strokeWidth={2}
                      dot={{ fill: "#9333ea" }}
                    />
                    <Line
                      type="monotone"
                      dataKey="despesas"
                      stroke="#db2777"
                      strokeWidth={2}
                      dot={{ fill: "#db2777" }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>

          {/* Classes Distribution */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-card-foreground">Alunos por Modalidade</CardTitle>
              <CardDescription>Distribuicao atual</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  alunos: { label: "Alunos", color: "#9333ea" },
                }}
                className="h-[300px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={classesData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                    <XAxis type="number" className="text-muted-foreground" />
                    <YAxis dataKey="name" type="category" width={100} className="text-muted-foreground" />
                    <ChartTooltip
                      content={({ active, payload, label }) => {
                        if (!active || !payload?.length) return null
                        return (
                          <div className="bg-background border border-border rounded-lg px-3 py-2 shadow-lg">
                            <p className="font-medium text-foreground">{label}</p>
                            <p className="text-sm text-primary">{payload[0].value} alunos</p>
                          </div>
                        )
                      }}
                    />
                    <Bar dataKey="alunos" fill="#9333ea" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Evasion Alerts */}
          <Card className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-card-foreground flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-warning" />
                  Alertas de Evasao
                </CardTitle>
                <CardDescription>Alunos em risco identificados pela IA</CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {evasionAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-secondary/50"
                  >
                    <div>
                      <p className="font-medium text-foreground">{alert.name}</p>
                      <p className="text-sm text-muted-foreground">
                        Ultima aula: {alert.lastClass}
                      </p>
                    </div>
                    <Badge
                      variant={alert.risk === "alto" ? "destructive" : "secondary"}
                      className={alert.risk === "alto" ? "" : "bg-warning/20 text-warning-foreground"}
                    >
                      Risco {alert.risk}
                    </Badge>
                  </div>
                ))}
              </div>
              <Link href="/dashboard/alunos">
                <Button variant="ghost" className="w-full mt-4 text-primary hover:text-primary/80">
                  Ver todos os alunos
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Upcoming Classes */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-card-foreground flex items-center gap-2">
                <Calendar className="w-5 h-5 text-primary" />
                Proximas Aulas
              </CardTitle>
              <CardDescription>Aulas agendadas para hoje</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingClasses.map((classItem) => (
                  <div
                    key={classItem.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-secondary/50"
                  >
                    <div>
                      <p className="font-medium text-foreground">{classItem.name}</p>
                      <p className="text-sm text-muted-foreground">{classItem.teacher}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-primary">{classItem.time}</p>
                      <p className="text-sm text-muted-foreground">
                        {classItem.students} alunos
                      </p>
                    </div>
                  </div>
                ))}
              </div>
              <Link href="/dashboard/aulas">
                <Button variant="ghost" className="w-full mt-4 text-primary hover:text-primary/80">
                  Ver agenda completa
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Student Age Distribution */}
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-card-foreground flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-accent" />
                Faixa Etaria
              </CardTitle>
              <CardDescription>Distribuicao dos alunos</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer
                config={{
                  Criancas: { label: "Criancas", color: "#9333ea" },
                  Adolescentes: { label: "Adolescentes", color: "#db2777" },
                  Adultos: { label: "Adultos", color: "#06b6d4" },
                }}
                className="h-[200px]"
              >
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={studentDistribution}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      strokeWidth={0}
                    >
                      {studentDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Pie>
                    <ChartTooltip
                      content={({ active, payload }) => {
                        if (!active || !payload?.length) return null
                        const data = payload[0].payload
                        return (
                          <div className="bg-background border border-border rounded-lg px-3 py-2 shadow-lg">
                            <p className="font-medium text-foreground">{data.name}</p>
                            <p className="text-sm text-muted-foreground">{data.value}%</p>
                          </div>
                        )
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </ChartContainer>
              <div className="flex justify-center gap-4 mt-4">
                {studentDistribution.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: item.fill }}
                    />
                    <span className="text-sm text-muted-foreground">
                      {item.name} ({item.value}%)
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
