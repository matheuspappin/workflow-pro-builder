"use client"

import { useState } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Download,
  Calendar,
  Users,
  CreditCard,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  FileText,
  GraduationCap,
} from "lucide-react"
import {
  Line,
  LineChart,
  XAxis,
  YAxis,
  CartesianGrid,
  ResponsiveContainer,
  Bar,
  BarChart,
  Area,
  AreaChart,
} from "recharts"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart"

// Mock data
const monthlyData = [
  { month: "Jul", receita: 15200, despesas: 8500, lucro: 6700 },
  { month: "Ago", receita: 14800, despesas: 8200, lucro: 6600 },
  { month: "Set", receita: 16500, despesas: 8800, lucro: 7700 },
  { month: "Out", receita: 17200, despesas: 9100, lucro: 8100 },
  { month: "Nov", receita: 18100, despesas: 9400, lucro: 8700 },
  { month: "Dez", receita: 19500, despesas: 9800, lucro: 9700 },
  { month: "Jan", receita: 18500, despesas: 9500, lucro: 9000 },
]

const expensesByCategory = [
  { category: "Professores", valor: 5500 },
  { category: "Aluguel", valor: 2500 },
  { category: "Utilidades", valor: 800 },
  { category: "Marketing", valor: 400 },
  { category: "Outros", valor: 300 },
]

const pendingPayments = [
  { id: 1, student: "Maria Silva", value: 250, dueDate: "2026-01-15", status: "atrasado", days: 8 },
  { id: 2, student: "Joao Santos", value: 200, dueDate: "2026-01-20", status: "pendente", days: 3 },
  { id: 3, student: "Pedro Lima", value: 230, dueDate: "2026-01-22", status: "pendente", days: 1 },
  { id: 4, student: "Ana Costa", value: 220, dueDate: "2026-01-25", status: "pendente", days: -2 },
  { id: 5, student: "Juliana Rocha", value: 250, dueDate: "2026-01-10", status: "atrasado", days: 13 },
]

const teacherPayments = [
  { id: 1, teacher: "Ana Paula Rodrigues", classes: 24, rate: 80, total: 1920, status: "pago" },
  { id: 2, teacher: "Carlos Eduardo Silva", classes: 20, rate: 70, total: 1400, status: "pendente" },
  { id: 3, teacher: "Lucas Oliveira", classes: 18, rate: 65, total: 1170, status: "pendente" },
  { id: 4, teacher: "Marina Santos", classes: 16, rate: 75, total: 1200, status: "pago" },
]

const recentTransactions = [
  { id: 1, description: "Mensalidade - Maria Silva", type: "entrada", value: 250, date: "2026-01-22" },
  { id: 2, description: "Pagamento Prof. Ana Paula", type: "saida", value: 1920, date: "2026-01-20" },
  { id: 3, description: "Mensalidade - Bruno Alves", type: "entrada", value: 220, date: "2026-01-19" },
  { id: 4, description: "Conta de Luz", type: "saida", value: 450, date: "2026-01-18" },
  { id: 5, description: "Mensalidade - Carla Mendes", type: "entrada", value: 180, date: "2026-01-18" },
  { id: 6, description: "Pagamento Prof. Marina", type: "saida", value: 1200, date: "2026-01-15" },
  { id: 7, description: "Material de Limpeza", type: "saida", value: 120, date: "2026-01-14" },
  { id: 8, description: "Mensalidade - Lucas Ferreira", type: "entrada", value: 200, date: "2026-01-12" },
]

export default function FinanceiroPage() {
  const [selectedMonth, setSelectedMonth] = useState("janeiro")
  const [activeTab, setActiveTab] = useState("visao-geral")

  const totalReceita = 18500
  const totalDespesas = 9500
  const lucroLiquido = totalReceita - totalDespesas
  const inadimplencia = pendingPayments.filter(p => p.status === "atrasado").reduce((acc, p) => acc + p.value, 0)

  return (
    <div className="min-h-screen bg-background">
      <Header title="Financeiro" />

      <div className="p-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-success/10 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-success" />
                </div>
                <div className="flex items-center gap-1 text-sm text-success">
                  <ArrowUpRight className="w-4 h-4" />
                  +12%
                </div>
              </div>
              <div className="mt-4">
                <p className="text-2xl font-bold text-card-foreground">R$ {totalReceita.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Receita do Mes</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center">
                  <TrendingDown className="w-6 h-6 text-destructive" />
                </div>
                <div className="flex items-center gap-1 text-sm text-destructive">
                  <ArrowDownRight className="w-4 h-4" />
                  +3%
                </div>
              </div>
              <div className="mt-4">
                <p className="text-2xl font-bold text-card-foreground">R$ {totalDespesas.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Despesas do Mes</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-primary" />
                </div>
                <div className="flex items-center gap-1 text-sm text-success">
                  <ArrowUpRight className="w-4 h-4" />
                  +18%
                </div>
              </div>
              <div className="mt-4">
                <p className="text-2xl font-bold text-card-foreground">R$ {lucroLiquido.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Lucro Liquido</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 rounded-xl bg-warning/10 flex items-center justify-center">
                  <CreditCard className="w-6 h-6 text-warning" />
                </div>
                <Badge variant="destructive" className="text-xs">Atencao</Badge>
              </div>
              <div className="mt-4">
                <p className="text-2xl font-bold text-card-foreground">R$ {inadimplencia.toLocaleString()}</p>
                <p className="text-sm text-muted-foreground">Inadimplencia</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <TabsList className="bg-secondary">
              <TabsTrigger value="visao-geral">Visao Geral</TabsTrigger>
              <TabsTrigger value="mensalidades">Mensalidades</TabsTrigger>
              <TabsTrigger value="professores">Professores</TabsTrigger>
              <TabsTrigger value="transacoes">Transacoes</TabsTrigger>
            </TabsList>

            <div className="flex gap-2">
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger className="w-[150px] bg-background">
                  <Calendar className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Mes" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="janeiro">Janeiro 2026</SelectItem>
                  <SelectItem value="dezembro">Dezembro 2025</SelectItem>
                  <SelectItem value="novembro">Novembro 2025</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" className="gap-2 bg-transparent">
                <Download className="w-4 h-4" />
                Exportar PDF
              </Button>
            </div>
          </div>

          {/* Visao Geral Tab */}
          <TabsContent value="visao-geral" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Revenue Chart */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Receita vs Despesas</CardTitle>
                  <CardDescription>Ultimos 7 meses</CardDescription>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      receita: { label: "Receita", color: "#22c55e" },
                      despesas: { label: "Despesas", color: "#ef4444" },
                    }}
                    className="h-[300px]"
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={monthlyData}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                        <XAxis dataKey="month" className="text-muted-foreground" />
                        <YAxis className="text-muted-foreground" />
                        <ChartTooltip
                          content={({ active, payload, label }) => {
                            if (!active || !payload?.length) return null
                            return (
                              <div className="bg-background border border-border rounded-lg px-3 py-2 shadow-lg">
                                <p className="font-medium text-foreground mb-1">{label}</p>
                                {payload.map((entry, index) => (
                                  <p key={index} className="text-sm" style={{ color: entry.color }}>
                                    {entry.dataKey === "receita" ? "Receita" : "Despesas"}: R$ {Number(entry.value).toLocaleString()}
                                  </p>
                                ))}
                              </div>
                            )
                          }}
                        />
                        <Area
                          type="monotone"
                          dataKey="receita"
                          stroke="#22c55e"
                          fill="#22c55e"
                          fillOpacity={0.2}
                          strokeWidth={2}
                        />
                        <Area
                          type="monotone"
                          dataKey="despesas"
                          stroke="#ef4444"
                          fill="#ef4444"
                          fillOpacity={0.2}
                          strokeWidth={2}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>

              {/* Expenses by Category */}
              <Card className="bg-card border-border">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Despesas por Categoria</CardTitle>
                  <CardDescription>Distribuicao mensal</CardDescription>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      valor: { label: "Valor", color: "#9333ea" },
                    }}
                    className="h-[300px]"
                  >
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={expensesByCategory} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                        <XAxis type="number" className="text-muted-foreground" />
                        <YAxis dataKey="category" type="category" width={100} className="text-muted-foreground" />
                        <ChartTooltip
                          content={({ active, payload, label }) => {
                            if (!active || !payload?.length) return null
                            return (
                              <div className="bg-background border border-border rounded-lg px-3 py-2 shadow-lg">
                                <p className="font-medium text-foreground">{label}</p>
                                <p className="text-sm text-primary">R$ {Number(payload[0].value).toLocaleString()}</p>
                              </div>
                            )
                          }}
                        />
                        <Bar dataKey="valor" fill="#9333ea" radius={[0, 4, 4, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>
            </div>

            {/* Profit Chart */}
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Evolucao do Lucro Liquido</CardTitle>
                <CardDescription>Tendencia dos ultimos meses</CardDescription>
              </CardHeader>
              <CardContent>
                <ChartContainer
                  config={{
                    lucro: { label: "Lucro", color: "#9333ea" },
                  }}
                  className="h-[250px]"
                >
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={monthlyData}>
                      <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                      <XAxis dataKey="month" className="text-muted-foreground" />
                      <YAxis className="text-muted-foreground" />
                        <ChartTooltip
                          content={({ active, payload, label }) => {
                            if (!active || !payload?.length) return null
                            return (
                              <div className="bg-background border border-border rounded-lg px-3 py-2 shadow-lg">
                                <p className="font-medium text-foreground">{label}</p>
                                <p className="text-sm text-primary">Lucro: R$ {Number(payload[0].value).toLocaleString()}</p>
                              </div>
                            )
                          }}
                        />
                      <Line
                        type="monotone"
                        dataKey="lucro"
                        stroke="#9333ea"
                        strokeWidth={3}
                        dot={{ fill: "#9333ea", strokeWidth: 2 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </ChartContainer>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Mensalidades Tab */}
          <TabsContent value="mensalidades" className="space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-card-foreground flex items-center gap-2">
                      <Users className="w-5 h-5 text-primary" />
                      Mensalidades Pendentes
                    </CardTitle>
                    <CardDescription>Alunos com pagamentos em aberto</CardDescription>
                  </div>
                  <Button variant="outline" className="gap-2 bg-transparent">
                    <FileText className="w-4 h-4" />
                    Enviar Cobranças
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Aluno</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Vencimento</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Acoes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingPayments.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell className="font-medium text-foreground">{payment.student}</TableCell>
                        <TableCell className="text-foreground">R$ {payment.value}</TableCell>
                        <TableCell className="text-muted-foreground">{payment.dueDate}</TableCell>
                        <TableCell>
                          {payment.status === "atrasado" ? (
                            <Badge variant="destructive">{payment.days} dias atrasado</Badge>
                          ) : payment.days < 0 ? (
                            <Badge className="bg-success/20 text-success-foreground">Em dia</Badge>
                          ) : (
                            <Badge className="bg-warning/20 text-warning-foreground">Vence em {payment.days} dias</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">Enviar Lembrete</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Professores Tab */}
          <TabsContent value="professores" className="space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-card-foreground flex items-center gap-2">
                      <GraduationCap className="w-5 h-5 text-primary" />
                      Pagamentos de Professores
                    </CardTitle>
                    <CardDescription>Controle de pagamentos por aula</CardDescription>
                  </div>
                  <Button className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2">
                    <Wallet className="w-4 h-4" />
                    Processar Pagamentos
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Professor</TableHead>
                      <TableHead>Aulas no Mes</TableHead>
                      <TableHead>Valor/Aula</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Acoes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {teacherPayments.map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell className="font-medium text-foreground">{payment.teacher}</TableCell>
                        <TableCell className="text-foreground">{payment.classes}</TableCell>
                        <TableCell className="text-muted-foreground">R$ {payment.rate}</TableCell>
                        <TableCell className="font-semibold text-foreground">R$ {payment.total.toLocaleString()}</TableCell>
                        <TableCell>
                          {payment.status === "pago" ? (
                            <Badge className="bg-success/20 text-success-foreground">Pago</Badge>
                          ) : (
                            <Badge className="bg-warning/20 text-warning-foreground">Pendente</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {payment.status === "pendente" && (
                            <Button variant="ghost" size="sm" className="text-primary">Pagar</Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                <div className="mt-6 p-4 bg-secondary/50 rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Total a Pagar</span>
                    <span className="text-xl font-bold text-foreground">
                      R$ {teacherPayments.filter(p => p.status === "pendente").reduce((acc, p) => acc + p.total, 0).toLocaleString()}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Transacoes Tab */}
          <TabsContent value="transacoes" className="space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Transacoes Recentes</CardTitle>
                <CardDescription>Historico de entradas e saidas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentTransactions.map((transaction) => (
                    <div
                      key={transaction.id}
                      className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors"
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          transaction.type === "entrada" ? "bg-success/10" : "bg-destructive/10"
                        }`}>
                          {transaction.type === "entrada" ? (
                            <ArrowUpRight className="w-5 h-5 text-success" />
                          ) : (
                            <ArrowDownRight className="w-5 h-5 text-destructive" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{transaction.description}</p>
                          <p className="text-sm text-muted-foreground">{transaction.date}</p>
                        </div>
                      </div>
                      <span className={`text-lg font-semibold ${
                        transaction.type === "entrada" ? "text-success" : "text-destructive"
                      }`}>
                        {transaction.type === "entrada" ? "+" : "-"} R$ {transaction.value.toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
