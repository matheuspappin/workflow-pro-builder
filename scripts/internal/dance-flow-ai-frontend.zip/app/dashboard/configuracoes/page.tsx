"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  User,
  Building,
  Bell,
  Shield,
  CreditCard,
  Palette,
  MessageSquare,
  Save,
  Loader2,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface StudioSettings {
  name: string
  email: string
  phone: string
  address: string
  cnpj: string
}

interface UserSettings {
  name: string
  email: string
  role: string
}

interface NotificationSettings {
  emailNotifications: boolean
  whatsappNotifications: boolean
  evasionAlerts: boolean
  paymentReminders: boolean
  classReminders: boolean
}

export default function SettingsPage() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("perfil")

  const [userSettings, setUserSettings] = useState<UserSettings>({
    name: "",
    email: "",
    role: "admin",
  })

  const [studioSettings, setStudioSettings] = useState<StudioSettings>({
    name: "",
    email: "",
    phone: "",
    address: "",
    cnpj: "",
  })

  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>({
    emailNotifications: true,
    whatsappNotifications: true,
    evasionAlerts: true,
    paymentReminders: true,
    classReminders: true,
  })

  const [appearance, setAppearance] = useState({
    theme: "light",
    language: "pt-BR",
  })

  useEffect(() => {
    const userData = localStorage.getItem("danceflow_user")
    if (userData) {
      const user = JSON.parse(userData)
      setUserSettings({
        name: user.name || "",
        email: user.email || "",
        role: user.role || "admin",
      })
      setStudioSettings({
        name: user.studioName || "",
        email: user.email || "",
        phone: "(11) 99999-9999",
        address: "Rua das Dancas, 123 - Sao Paulo, SP",
        cnpj: "00.000.000/0001-00",
      })
    }
  }, [])

  const handleSave = async () => {
    setIsLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))
    
    // Update localStorage
    const currentUser = JSON.parse(localStorage.getItem("danceflow_user") || "{}")
    localStorage.setItem("danceflow_user", JSON.stringify({
      ...currentUser,
      name: userSettings.name,
      email: userSettings.email,
      studioName: studioSettings.name,
    }))

    toast({
      title: "Configuracoes salvas!",
      description: "Suas alteracoes foram salvas com sucesso.",
    })
    setIsLoading(false)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header title="Configuracoes" />

      <div className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="bg-secondary flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="perfil" className="gap-2">
              <User className="w-4 h-4" />
              Perfil
            </TabsTrigger>
            <TabsTrigger value="estudio" className="gap-2">
              <Building className="w-4 h-4" />
              Estudio
            </TabsTrigger>
            <TabsTrigger value="notificacoes" className="gap-2">
              <Bell className="w-4 h-4" />
              Notificacoes
            </TabsTrigger>
            <TabsTrigger value="aparencia" className="gap-2">
              <Palette className="w-4 h-4" />
              Aparencia
            </TabsTrigger>
            <TabsTrigger value="integracao" className="gap-2">
              <MessageSquare className="w-4 h-4" />
              Integracoes
            </TabsTrigger>
            <TabsTrigger value="seguranca" className="gap-2">
              <Shield className="w-4 h-4" />
              Seguranca
            </TabsTrigger>
            <TabsTrigger value="plano" className="gap-2">
              <CreditCard className="w-4 h-4" />
              Plano
            </TabsTrigger>
          </TabsList>

          {/* Perfil Tab */}
          <TabsContent value="perfil" className="space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Informacoes Pessoais</CardTitle>
                <CardDescription>Atualize suas informacoes de perfil</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-6">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-white text-2xl font-bold">
                    {userSettings.name.split(" ").map(n => n[0]).slice(0, 2).join("") || "U"}
                  </div>
                  <div>
                    <Button variant="outline">Alterar Foto</Button>
                    <p className="text-xs text-muted-foreground mt-2">JPG, PNG ou GIF. Max 2MB</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome Completo</Label>
                    <Input
                      id="name"
                      value={userSettings.name}
                      onChange={(e) => setUserSettings({ ...userSettings, name: e.target.value })}
                      className="bg-background"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={userSettings.email}
                      onChange={(e) => setUserSettings({ ...userSettings, email: e.target.value })}
                      className="bg-background"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role">Funcao</Label>
                  <Select value={userSettings.role} onValueChange={(value) => setUserSettings({ ...userSettings, role: value })}>
                    <SelectTrigger className="w-full md:w-[200px] bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">Administrador</SelectItem>
                      <SelectItem value="manager">Gerente</SelectItem>
                      <SelectItem value="receptionist">Recepcionista</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Estudio Tab */}
          <TabsContent value="estudio" className="space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Dados do Estudio</CardTitle>
                <CardDescription>Informacoes do seu estabelecimento</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="studioName">Nome do Estudio</Label>
                    <Input
                      id="studioName"
                      value={studioSettings.name}
                      onChange={(e) => setStudioSettings({ ...studioSettings, name: e.target.value })}
                      className="bg-background"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="studioCnpj">CNPJ</Label>
                    <Input
                      id="studioCnpj"
                      value={studioSettings.cnpj}
                      onChange={(e) => setStudioSettings({ ...studioSettings, cnpj: e.target.value })}
                      placeholder="00.000.000/0001-00"
                      className="bg-background"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="studioEmail">Email do Estudio</Label>
                    <Input
                      id="studioEmail"
                      type="email"
                      value={studioSettings.email}
                      onChange={(e) => setStudioSettings({ ...studioSettings, email: e.target.value })}
                      className="bg-background"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="studioPhone">Telefone</Label>
                    <Input
                      id="studioPhone"
                      value={studioSettings.phone}
                      onChange={(e) => setStudioSettings({ ...studioSettings, phone: e.target.value })}
                      className="bg-background"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="studioAddress">Endereco Completo</Label>
                  <Textarea
                    id="studioAddress"
                    value={studioSettings.address}
                    onChange={(e) => setStudioSettings({ ...studioSettings, address: e.target.value })}
                    className="bg-background"
                    rows={2}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notificacoes Tab */}
          <TabsContent value="notificacoes" className="space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Preferencias de Notificacao</CardTitle>
                <CardDescription>Configure como deseja receber alertas</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-foreground">Notificacoes por Email</p>
                    <p className="text-sm text-muted-foreground">Receba atualizacoes importantes por email</p>
                  </div>
                  <Switch
                    checked={notificationSettings.emailNotifications}
                    onCheckedChange={(checked) => setNotificationSettings({ ...notificationSettings, emailNotifications: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-foreground">Notificacoes por WhatsApp</p>
                    <p className="text-sm text-muted-foreground">Receba alertas via WhatsApp</p>
                  </div>
                  <Switch
                    checked={notificationSettings.whatsappNotifications}
                    onCheckedChange={(checked) => setNotificationSettings({ ...notificationSettings, whatsappNotifications: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-foreground">Alertas de Evasao</p>
                    <p className="text-sm text-muted-foreground">Seja notificado sobre alunos em risco</p>
                  </div>
                  <Switch
                    checked={notificationSettings.evasionAlerts}
                    onCheckedChange={(checked) => setNotificationSettings({ ...notificationSettings, evasionAlerts: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-foreground">Lembretes de Pagamento</p>
                    <p className="text-sm text-muted-foreground">Alertas sobre mensalidades pendentes</p>
                  </div>
                  <Switch
                    checked={notificationSettings.paymentReminders}
                    onCheckedChange={(checked) => setNotificationSettings({ ...notificationSettings, paymentReminders: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-foreground">Lembretes de Aulas</p>
                    <p className="text-sm text-muted-foreground">Notificacoes sobre aulas proximas</p>
                  </div>
                  <Switch
                    checked={notificationSettings.classReminders}
                    onCheckedChange={(checked) => setNotificationSettings({ ...notificationSettings, classReminders: checked })}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aparencia Tab */}
          <TabsContent value="aparencia" className="space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Aparencia</CardTitle>
                <CardDescription>Personalize a interface do sistema</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Tema</Label>
                  <Select value={appearance.theme} onValueChange={(value) => setAppearance({ ...appearance, theme: value })}>
                    <SelectTrigger className="w-full md:w-[200px] bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Claro</SelectItem>
                      <SelectItem value="dark">Escuro</SelectItem>
                      <SelectItem value="system">Sistema</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Idioma</Label>
                  <Select value={appearance.language} onValueChange={(value) => setAppearance({ ...appearance, language: value })}>
                    <SelectTrigger className="w-full md:w-[200px] bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pt-BR">Portugues (Brasil)</SelectItem>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Espanol</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Integracoes Tab */}
          <TabsContent value="integracao" className="space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Integracoes</CardTitle>
                <CardDescription>Conecte servicos externos ao sistema</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-success/10 flex items-center justify-center">
                      <MessageSquare className="w-6 h-6 text-success" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">WhatsApp Business</p>
                      <p className="text-sm text-muted-foreground">Envie mensagens automaticas para alunos</p>
                    </div>
                  </div>
                  <Button variant="outline">Configurar</Button>
                </div>
                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                      <CreditCard className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">Gateway de Pagamento</p>
                      <p className="text-sm text-muted-foreground">Receba pagamentos online</p>
                    </div>
                  </div>
                  <Button variant="outline">Conectar</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Seguranca Tab */}
          <TabsContent value="seguranca" className="space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Seguranca da Conta</CardTitle>
                <CardDescription>Gerencie a seguranca da sua conta</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="currentPassword">Senha Atual</Label>
                  <Input id="currentPassword" type="password" className="bg-background max-w-md" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-md">
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">Nova Senha</Label>
                    <Input id="newPassword" type="password" className="bg-background" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirmar Senha</Label>
                    <Input id="confirmPassword" type="password" className="bg-background" />
                  </div>
                </div>
                <Button variant="outline">Alterar Senha</Button>

                <div className="pt-6 border-t border-border">
                  <h4 className="font-medium text-foreground mb-4">Autenticacao em Dois Fatores</h4>
                  <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div>
                      <p className="font-medium text-foreground">2FA via SMS</p>
                      <p className="text-sm text-muted-foreground">Adicione uma camada extra de seguranca</p>
                    </div>
                    <Switch />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Plano Tab */}
          <TabsContent value="plano" className="space-y-6">
            <Card className="bg-card border-border">
              <CardHeader>
                <CardTitle className="text-card-foreground">Seu Plano</CardTitle>
                <CardDescription>Gerencie sua assinatura</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="p-6 border-2 border-primary rounded-xl bg-primary/5">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-foreground">Professional</h3>
                      <p className="text-muted-foreground">Ate 200 alunos, IA integrada</p>
                    </div>
                    <div className="text-right">
                      <p className="text-3xl font-bold text-primary">R$ 197</p>
                      <p className="text-sm text-muted-foreground">/mes</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-success" />
                      <span className="text-muted-foreground">145 de 200 alunos</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-success" />
                      <span className="text-muted-foreground">5 usuarios ativos</span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button variant="outline">Trocar Plano</Button>
                  <Button variant="outline" className="text-destructive border-destructive hover:bg-destructive/10 bg-transparent">
                    Cancelar Assinatura
                  </Button>
                </div>

                <div className="pt-6 border-t border-border">
                  <h4 className="font-medium text-foreground mb-4">Historico de Faturas</h4>
                  <div className="space-y-3">
                    {[
                      { date: "Jan 2026", value: "R$ 197,00", status: "Pago" },
                      { date: "Dez 2025", value: "R$ 197,00", status: "Pago" },
                      { date: "Nov 2025", value: "R$ 197,00", status: "Pago" },
                    ].map((invoice, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                        <span className="text-foreground">{invoice.date}</span>
                        <span className="text-muted-foreground">{invoice.value}</span>
                        <span className="text-success text-sm">{invoice.status}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Save Button */}
        <div className="flex justify-end mt-6">
          <Button
            onClick={handleSave}
            className="bg-primary hover:bg-primary/90 text-primary-foreground gap-2"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Salvando...
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                Salvar Alteracoes
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}
